#' Lieberson Recommendation
#' 
#' Post-QCA, this function takes in the parameters of QCA data set, the configurational n thresholds identified in the truth table, and the range of consistency scores. LrQCA simulates all possible combinations of this information to provide recommendations to improve upon randomness in the QCA solutions (diminish random results). 
#' @param qca.data: The QCA data frame.
#' @param outcome: The outcome variable in the QCA data frame (qca.data).
#' @param type: crisp or fuzzy sets
#' @param inclcut: Minimum consistency score for inclusion.
#' @param ncut: configurational n levels to simulate. Usually start with 2 all the way up to the max score identified by the truth table.
#' @return Significance levels reached (.05, .01, .001) by improving the original QCA model's consistency score and configurational n threshold.
#' @export
lrQCA<-function(qca.data, outcome="OUT", type="crisp", inclcut = "", ncut=2, neg.out=F, sim=10, verbose=T, conv.diag=F){
source("R/sim.ltQCA.R")
source("R/configuration.table.R")
library("QCA")

s.data<-sim.ltQCA(qca.data, outcome, inclcut = inclcut, ncut=ncut, sim=sim, neg.out=F, type=type, verbose=verbose)
results<-conf.table(s.data, ncut)
return(results)
}

rvQCA<-function(qca.data, outcome="OUT", conditions=c(""), type="crisp", ncut=4, sim=100){
  source("combined.Gamson.sim.R")
  source("configuration.table.R")
  source("rvQCA.R")
  library("QCA")
    s.data<-sim.rvQCA(qca.data, outcome, ncut=ncut, sim=sim)
    results<-conf.table(s.data, ncut)
    return(results)
  }